// Sample placeholder Spring Boot controller for Month_2
public class MainController {
    // GET /api/ping -> returns pong
}
