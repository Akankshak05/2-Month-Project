# Backend - Month_2

Spring Boot (Java) backend skeleton for Month_2 of Zidio Connect.

Contains sample controllers, services, and models as placeholders.

Run instructions (example):
```
cd backend
mvn spring-boot:run
```
