Month 2 Summary:

- Developed Recruiter module: Job posting APIs, recruiter dashboard placeholders.
- Implemented application submission APIs and frontend forms.
- Integrated frontend with backend API endpoints (placeholder links).
- Wrote basic validation and sample data scripts.
