# Frontend - Month_2

React.js frontend skeleton for Month_2 of Zidio Connect.

Run instructions:
```
cd frontend
npm install
npm start
```
