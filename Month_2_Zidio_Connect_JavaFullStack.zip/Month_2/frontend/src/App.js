// Placeholder React App for Month_2
function App() {
  return (<div><h1>Zidio Connect - Month_2</h1></div>);
}
export default App;